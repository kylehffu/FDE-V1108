import re
import sys

server_file = '/Users/haifeng/sale-fde/FDE-V1108/server.ts'
with open(server_file, 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Insert universal LLM gateway right after aiClient initialization
gateway_def = '''// ==============================================================================
// Persistent Runtime Configuration for Universal Multi-LLM API Gateway
// ==============================================================================
interface LlmRuntimeConfig {
  provider: 'gemini' | 'openai-compatible' | 'deepseek' | 'qwen' | 'custom' | 'mock';
  apiKey: string;
  baseUrl: string;
  model: string;
  temperature: number;
}

const CONFIG_FILE = path.join(__dirname, '.llm-config.json');

function loadLlmConfig(): LlmRuntimeConfig {
  const envProvider = (process.env.LLM_PROVIDER as any) || (process.env.GEMINI_API_KEY ? 'gemini' : 'deepseek');
  const envApiKey =
    process.env.LLM_API_KEY ||
    process.env.DEEPSEEK_API_KEY ||
    process.env.OPENAI_API_KEY ||
    process.env.GEMINI_API_KEY ||
    '';
  const envBaseUrl =
    process.env.LLM_BASE_URL ||
    (envProvider === 'deepseek' ? 'https://api.deepseek.com' : 'https://api.openai.com/v1');
  const envModel =
    process.env.LLM_MODEL ||
    (envProvider === 'gemini'
      ? 'gemini-3.1-flash-lite'
      : envProvider === 'deepseek'
      ? 'deepseek-chat'
      : 'gpt-4o-mini');

  const defaultConfig: LlmRuntimeConfig = {
    provider: envProvider,
    apiKey: envApiKey,
    baseUrl: envBaseUrl,
    model: envModel,
    temperature: 0.3,
  };

  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
      return { ...defaultConfig, ...data };
    }
  } catch (err) {
    console.warn('[Config] Failed to load .llm-config.json, using defaults:', err);
  }
  return defaultConfig;
}

function saveLlmConfig(config: LlmRuntimeConfig) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
  } catch (err) {
    console.error('[Config] Failed to save .llm-config.json:', err);
  }
}

let activeLlmConfig = loadLlmConfig();

// Unified caller supporting Gemini native, OpenAI-compatible (DeepSeek, Qwen / DashScope, OpenAI, Ollama, vLLM)
async function callUniversalLlm(prompt: string, configOverride?: Partial<LlmRuntimeConfig>): Promise<string> {
  const cfg = { ...activeLlmConfig, ...configOverride };

  if (cfg.provider === 'mock' || !cfg.apiKey) {
    throw new Error('LLM provider is mock or missing API key; falling back to heuristic OSINT engine');
  }

  // 1. Google Gemini Native SDK
  if (cfg.provider === 'gemini') {
    const client = new GoogleGenAI({
      apiKey: cfg.apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await withTimeout(
      client.models.generateContent({
        model: cfg.model || 'gemini-3.1-flash-lite',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: cfg.temperature ?? 0.3,
        },
      }),
      8500
    );
    return (response.text || '').trim();
  }

  // 2. OpenAI-Compatible (DeepSeek, Qwen / DashScope, OpenAI, Ollama, vLLM, OneAPI)
  let endpoint = cfg.baseUrl.replace(/\\/+$/, '');
  if (!endpoint.endsWith('/chat/completions')) {
    endpoint = `${endpoint}/chat/completions`;
  }

  const payload: any = {
    model: cfg.model,
    messages: [
      {
        role: 'system',
        content: 'You are an expert consultative sales co-pilot and biomedical intelligence consultant. Output pure valid JSON only when requested, with no markdown codeblocks.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: cfg.temperature ?? 0.3,
  };

  const response = await withTimeout(
    fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify(payload),
    }),
    9500
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`LLM API returned ${response.status}: ${errText}`);
  }

  const data: any = await response.json();
  const content = data.choices?.[0]?.message?.content || '';
  return content.trim();
}
'''

init_target = '''let aiClient: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}'''

assert init_target in text, 'init_target not found'
text = text.replace(init_target, init_target + '\n\n' + gateway_def)

# 2. Add LLM Config REST endpoints right before app.post('/api/gemini/deduce'
config_endpoints = '''// ==============================================================================
// REST Endpoints for Runtime LLM Configuration & Testing
// ==============================================================================
app.get('/api/llm/config', (req, res) => {
  const maskedKey = activeLlmConfig.apiKey
    ? `${activeLlmConfig.apiKey.slice(0, 4)}...${activeLlmConfig.apiKey.slice(-4)}`
    : '';
  res.json({
    success: true,
    data: {
      provider: activeLlmConfig.provider,
      model: activeLlmConfig.model,
      baseUrl: activeLlmConfig.baseUrl,
      temperature: activeLlmConfig.temperature,
      hasApiKey: !!activeLlmConfig.apiKey,
      apiKeyMasked: maskedKey,
    },
    // Also provide flat properties for compatibility
    provider: activeLlmConfig.provider,
    model: activeLlmConfig.model,
    baseUrl: activeLlmConfig.baseUrl,
    temperature: activeLlmConfig.temperature,
    hasKey: !!activeLlmConfig.apiKey,
    maskedKey,
  });
});

app.post('/api/llm/config', (req, res) => {
  const { provider, apiKey, baseUrl, model, temperature } = req.body;
  if (provider) activeLlmConfig.provider = provider;
  if (typeof apiKey === 'string') {
    if (apiKey.trim()) {
      activeLlmConfig.apiKey = apiKey.trim();
    }
  }
  if (baseUrl) activeLlmConfig.baseUrl = baseUrl.trim();
  if (model) activeLlmConfig.model = model.trim();
  if (typeof temperature === 'number') activeLlmConfig.temperature = temperature;

  saveLlmConfig(activeLlmConfig);
  res.json({ success: true, config: { ...activeLlmConfig, apiKey: '***' } });
});

app.post('/api/llm/test', async (req, res) => {
  const testCfg = req.body;
  try {
    const testPrompt = 'Respond with JSON only: {"status": "ok", "provider": "connected", "message": "API connected successfully"}';
    const raw = await callUniversalLlm(testPrompt, testCfg);
    const cleaned = raw.replace(/^```json\\s*/i, '').replace(/^```\\s*/i, '').replace(/\\s*```$/, '');
    res.json({ success: true, raw: cleaned });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});
'''

deduce_start = "app.post('/api/gemini/deduce', async (req, res) => {"
assert deduce_start in text, 'deduce_start not found'
text = text.replace(
    deduce_start,
    config_endpoints + "\nasync function handleDeductionRequest(req: express.Request, res: express.Response) {\n"
)

# 3. In handleDeductionRequest: replace aiClient.models.generateContent call
deduce_call_old = '''  if (canCallGemini() && aiClient) {
    try {
      const response = await withTimeout(
        aiClient.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        }),
        4500
      );

      const responseText = (response.text || '').trim();
      const cleaned = responseText
        .replace(/^```json\\s*/i, '')
        .replace(/^```\\s*/i, '')
        .replace(/\\s*```$/, '');
      const parsed = JSON.parse(cleaned);
      if (parsed && parsed.needAnalysis) {
        return res.json({ success: true, source: 'gemini-3.1-flash-lite', data: parsed });
      }
    } catch (err: any) {
      recordGeminiFallback('Deduce', err);
    }
  }

  return res.json({ success: true, source: 'dynamic-expert-engine', data: fallbackData });
});'''

deduce_call_new = '''  try {
    const responseText = await callUniversalLlm(prompt);
    const cleaned = responseText
      .replace(/^```json\\s*/i, '')
      .replace(/^```\\s*/i, '')
      .replace(/\\s*```$/, '');
    const parsed = JSON.parse(cleaned);
    if (parsed && parsed.needAnalysis) {
      return res.json({ success: true, source: activeLlmConfig.provider + ':' + activeLlmConfig.model, data: parsed });
    }
  } catch (err: any) {
    recordGeminiFallback('Deduce', err);
  }

  return res.json({ success: true, source: 'dynamic-expert-engine', data: fallbackData });
}

app.post('/api/ai/deduce', handleDeductionRequest);
app.post('/api/gemini/deduce', handleDeductionRequest);'''

assert deduce_call_old in text, 'deduce_call_old not found'
text = text.replace(deduce_call_old, deduce_call_new)

# 4. In /api/intel/match-scholar: replace Gemini call with callUniversalLlm
match_old_block = '''      const response = await withTimeout(
        aiClient.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: matchPrompt,
          config: {
            tools: [{ googleSearch: {} }],
          },
        }),
        6500
      );

      const rawText = (response.text || '').trim();'''

match_new_block = '''      let rawText = '';
      if (activeLlmConfig.provider === 'gemini' && aiClient) {
        const response = await withTimeout(
          aiClient.models.generateContent({
            model: activeLlmConfig.model || 'gemini-3-flash-preview',
            contents: matchPrompt,
            config: {
              tools: [{ googleSearch: {} }],
            },
          }),
          6500
        );
        rawText = (response.text || '').trim();
      } else {
        rawText = await callUniversalLlm(matchPrompt);
      }'''

assert match_old_block in text, 'match_old_block not found'
text = text.replace(match_old_block, match_new_block)

# 5. In /api/intel/crawl: replace aiClient.models.generateContent with callUniversalLlm
crawl_target = '''  let aiSynthesis: any = null;
  if (canCallGemini() && aiClient && !isPreVerifiedCrawlScholar) {
    try {
      const response = await withTimeout(
        aiClient.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: aiPrompt,
          config: {
            responseMimeType: 'application/json',
          },
        }),
        4500
      );
      const cleaned = (response.text || '{}')
        .trim()
        .replace(/^```json\\s*/i, '')
        .replace(/^```\\s*/i, '')
        .replace(/\\s*```$/, '');
      aiSynthesis = JSON.parse(cleaned);
    } catch (err: any) {
      recordGeminiFallback('IntelCrawl', err);
    }
  }'''

crawl_replace = '''  let aiSynthesis: any = null;
  if (!isPreVerifiedCrawlScholar) {
    try {
      let rawText = '';
      if (activeLlmConfig.provider === 'gemini' && aiClient) {
        const response = await withTimeout(
          aiClient.models.generateContent({
            model: activeLlmConfig.model || 'gemini-3-flash-preview',
            contents: aiPrompt,
            config: {
              responseMimeType: 'application/json',
            },
          }),
          4500
        );
        rawText = response.text || '{}';
      } else {
        rawText = await callUniversalLlm(aiPrompt);
      }
      const cleaned = (rawText || '{}')
        .trim()
        .replace(/^```json\\s*/i, '')
        .replace(/^```\\s*/i, '')
        .replace(/\\s*```$/, '');
      aiSynthesis = JSON.parse(cleaned);
    } catch (err: any) {
      recordGeminiFallback('IntelCrawl', err);
    }
  }'''

assert crawl_target in text, 'crawl_target not found'
text = text.replace(crawl_target, crawl_replace)

# 6. In /api/battle-guide/synthesize: replace aiClient.models.generateContent with callUniversalLlm
synth_target = '''  if (canCallGemini() && aiClient && !scenario.isUnreachableLeader && !isPreVerifiedSynthScholar) {
    try {
      const llmPrompt = `'''

synth_call_target = '''      const response = await withTimeout(
        aiClient.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: llmPrompt,
          config: {
            responseMimeType: 'application/json',
          },
        }),
        5500
      );

      if (response.text) {
        const cleaned = response.text
          .replace(/^```json\\s*/i, '')
          .replace(/```\\s*$/i, '')
          .trim();
        const aiJson = JSON.parse(cleaned);'''

synth_call_replace = '''      let rawText = '';
      if (activeLlmConfig.provider === 'gemini' && aiClient) {
        const response = await withTimeout(
          aiClient.models.generateContent({
            model: activeLlmConfig.model || 'gemini-3-flash-preview',
            contents: llmPrompt,
            config: {
              responseMimeType: 'application/json',
            },
          }),
          5500
        );
        rawText = response.text || '';
      } else {
        rawText = await callUniversalLlm(llmPrompt);
      }

      if (rawText) {
        const cleaned = rawText
          .replace(/^```json\\s*/i, '')
          .replace(/```\\s*$/i, '')
          .trim();
        const aiJson = JSON.parse(cleaned);'''

assert synth_call_target in text, 'synth_call_target not found'
text = text.replace(synth_call_target, synth_call_replace)

text = text.replace(
    "if (canCallGemini() && aiClient && !scenario.isUnreachableLeader && !isPreVerifiedSynthScholar) {",
    "if (!scenario.isUnreachableLeader && !isPreVerifiedSynthScholar) {"
)

# 7. In /api/intel/deep-profile: replace aiClient call with callUniversalLlm or fallback
deep_target = '''      const response = await withTimeout(
        aiClient.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: searchPrompt,
          config: {
            tools: [{ googleSearch: {} }],
          },
        }),
        8500
      );

      const rawText = (response.text || '').trim();'''

deep_replace = '''      let rawText = '';
      if (activeLlmConfig.provider === 'gemini' && aiClient) {
        const response = await withTimeout(
          aiClient.models.generateContent({
            model: activeLlmConfig.model || 'gemini-3-flash-preview',
            contents: searchPrompt,
            config: {
              tools: [{ googleSearch: {} }],
            },
          }),
          8500
        );
        rawText = (response.text || '').trim();
      } else {
        rawText = await callUniversalLlm(searchPrompt);
      }'''

assert deep_target in text, 'deep_target not found'
text = text.replace(deep_target, deep_replace)

with open(server_file, 'w', encoding='utf-8') as f:
    f.write(text)

print('SUCCESS: FDE-V1108 server.ts patched!')
