import React, { createContext, useContext, useState, useEffect } from 'react';

export type IndustrySectorId = 'biomed' | 'semicon_mfg' | 'enterprise_ai' | 'chem_materials';

export interface IndustrySectorMeta {
  id: IndustrySectorId;
  shortLabel: string;
  fullName: string;
  orgLabel: string;
  deptLabel: string;
  personLabel: string;
  keywordLabel: string;
  orgPlaceholder: string;
  deptPlaceholder: string;
  personPlaceholder: string;
  keywordPlaceholder: string;
  opexLabel: string;
  capexLabel: string;
}

export const B2B_INDUSTRY_SECTORS: IndustrySectorMeta[] = [
  {
    id: 'biomed',
    shortLabel: '生命科学 / 医疗临床',
    fullName: '三甲医院临床科室与科研院所',
    orgLabel: '目标医院 / 科研院所',
    deptLabel: '所属科室 / 实验室',
    personLabel: '客户姓名',
    keywordLabel: '研究或临床业务方向',
    orgPlaceholder: '如：中山大学附属第一医院',
    deptPlaceholder: '如：医学检验科 / 消化内科 / 肝胆外科',
    personPlaceholder: '如：欧阳涓 / 陈旻湖 / 匡铭',
    keywordPlaceholder: '如：流式MRD / IBD黏膜免疫 / 肝癌消融',
    opexLabel: '≤5万元课题测试化验加工费（子课题负责人直接签批）',
    capexLabel: '200-350万元院级设备修购专项（需提前3-6个月提报立项论证）',
  },
  {
    id: 'semicon_mfg',
    shortLabel: '半导体 / 高端制造',
    fullName: '半导体、新能源汽车与高端制造产线',
    orgLabel: '目标制造企业',
    deptLabel: '事业部 / 研发中心 / 产线',
    personLabel: '客户姓名',
    keywordLabel: '工艺方向或产线检测环节',
    orgPlaceholder: '如：比亚迪半导体 / 宁德时代21C实验室',
    deptPlaceholder: '如：功率半导体事业部 / 失效分析(FA)中心',
    personPlaceholder: '如：陈刚 / 欧阳楚英',
    keywordPlaceholder: '如：SiC银烧结空洞率 / 在线3D无损检测',
    opexLabel: '≤10万元研发打样与失效分析验证费（部门副总/总监直接签批）',
    capexLabel: '500-1200万元产线扩产在线检测设备（需提前4-6个月完成AVL准入）',
  },
  {
    id: 'enterprise_ai',
    shortLabel: '政企数字化 / 金融科技',
    fullName: '金融机构科技部与大型政企数字化中心',
    orgLabel: '目标金融机构 / 企业',
    deptLabel: '科技部二级中心 / 架构部',
    personLabel: '客户姓名',
    keywordLabel: '系统架构或AI算力场景',
    orgPlaceholder: '如：招商银行总行信息技术部',
    deptPlaceholder: '如：云原生与AI算力中心 / 数据架构部',
    personPlaceholder: '如：周天虹 / 李云',
    keywordPlaceholder: '如：私有化大模型低延时推理 / 分布式向量数据库',
    opexLabel: '≤15万元部门级POC技术验证与试点预算（二级中心主任直接签批）',
    capexLabel: '800-2000万元年度软硬件集采框招（Q3技术委员会审定技术规范）',
  },
  {
    id: 'chem_materials',
    shortLabel: '化工新材料 / 能源央企',
    fullName: '化工新材料中央研究院与中试基地',
    orgLabel: '目标化工集团 / 能源企业',
    deptLabel: '中央研究院 / 专业研究所',
    personLabel: '客户姓名',
    keywordLabel: '催化聚合工艺或材料表征方向',
    orgPlaceholder: '如：万华化学集团中央研究院',
    deptPlaceholder: '如：高性能聚合物研究所 / POE催化工程中心',
    personPlaceholder: '如：华卫琦 / 张永振',
    keywordPlaceholder: '如：茂金属POE催化剂 / 高温在线流变与GPC表征',
    opexLabel: '≤8万元所级定制表征与耗材测试费（研究所所长直接签批）',
    capexLabel: '400-900万元百吨级中试放大线在线监测与高通量表征平台',
  },
];

export interface ConfirmedCustomerProfile {
  id: string;
  industrySector?: IndustrySectorId;
  institution: string;
  department: string;
  scholarName: string;
  title: string;
  researchKeywords: string;
  englishQuery: string;
  correctionBadge?: string;
  deptLeaderName?: string;
  personTier?: 'L1' | 'L2' | 'L3' | 'L4';
  roleRelationNote?: string;
  subPiNames?: string;
  firstAuthorNames?: string;
  verifiedReason?: string;
  officialSiteSchedule?: string;
  procurementHistoryClue?: string;
  patentCoInventorsClue?: string;
  confirmedAt: string;
}

interface CustomerContextValue {
  activeIndustry: IndustrySectorId;
  setActiveIndustry: (sector: IndustrySectorId) => void;
  confirmedCustomer: ConfirmedCustomerProfile | null;
  customerHistory: ConfirmedCustomerProfile[];
  isSelectingCustomer: boolean;
  setIsSelectingCustomer: (open: boolean) => void;
  confirmCustomer: (
    profile: Omit<ConfirmedCustomerProfile, 'id' | 'confirmedAt' | 'title' | 'englishQuery'> & {
      id?: string;
      title?: string;
      englishQuery?: string;
    }
  ) => ConfirmedCustomerProfile;
  selectFromHistory: (id: string) => void;
  removeFromHistory: (id: string) => void;
}

const STORAGE_HISTORY_KEY = 'fde_confirmed_customer_history_v7';
const STORAGE_ACTIVE_KEY = 'fde_confirmed_active_customer_v7';

const INITIAL_SEED_HISTORY: ConfirmedCustomerProfile[] = [
  {
    id: 'jnu-yin-zhinan',
    industrySector: 'biomed',
    institution: '暨南大学',
    department: '生物医学转化研究院 / 广东暨德康民 & 暨安特博（名下转化企业） / 珠海市人民医院精准医学中心',
    scholarName: '尹芝南',
    title:
      '生物医学转化研究院院长 / 广东暨德康民创始人·首席科学家(持股~33%) / 广东暨安特博科学创始人 / 国家杰青(30725015) / 长江学者 / 973首席',
    researchKeywords:
      '同种异体Vγ9Vδ2-T细胞新药(GDKM-100) · IL-27靶向脂肪产热减肥与代谢免疫(Nature) · 肿瘤免疫微环境转化',
    englishQuery: 'Jinan University Zhinan Yin gamma delta T cells tumor immunotherapy IL-27',
    deptLeaderName:
      '尹芝南（暨大生物医学转化研究院院长 + 广东暨德康民创始人/大股东[持股~33%] + 广东暨安特博创始人 + 普锐生物首席科学家 + 珠海市人民医院学术总监）',
    personTier: 'L1',
    roleRelationNote:
      '【体制内研究院 + 院外名下商业药企双栖全景】① 院内行政与课题班子：尹芝南任院长（原耶鲁医学院副教授、南开生科院院长、广东省免疫学会理事长），副院长【吴扬哲教授】分管院内平台与γδ-T免疫评价，【杨恒文副研究员】（IL-27与肠道微生态）、【高云飞教授】（γδ-T与银屑病谷氨酰胺代谢JCI）、【罗钧洪教授】（海外优青·AI单细胞MIST模型）分管各主力课题组；② 院外名下商业公司（免高校招标直采突破口！）：尹芝南创办【广东暨德康民生物科技有限公司】（持股约33%，董事长王亚杰，院内PI【向征博士】兼任执行总经理兼CTO，2025年12月完成广州金控健康产投领投B轮融资，中国首个异体γδ-T新药GDKM-100获NMPA临床批件并在暨大附一院启动晚期肝癌I期临床）及【广东暨安特博生物科技有限责任公司】（获真格基金、香商投资数千万投资研发IL-27新药），并任【普锐生物】首席科学家。',
    subPiNames:
      '向征（转化研究院PI + 广东暨德康民执行总经理兼CTO·掌管GDKM-100临床与企业采购权）、吴扬哲（生物医学转化研究院副院长/教授·分管平台与γδ-T评价）、杨恒文（副研究员/PI·肠道微生态与IL-27代谢）、高云飞（教授/PI·γδ-T与银屑病代谢）、罗钧洪（教授/海外优青·AI单细胞多组学）',
    firstAuthorNames:
      '鲁呦呦 / 裴建 / 陈娜 / 王倩（γδ-T细胞分选扩增、GDKM-100临床样本监测与IL-27代谢免疫一线专职博后）',
    verifiedReason:
      '兼具“暨大转化研究院院长（国自然重点318300xx/973首席）”与“广东暨德康民（B轮）/广东暨安特博（真格投资）实控创始人”双重身份；院内找吴扬哲/杨恒文/高云飞，企业商业合同直接找CTO向征博士！',
    officialSiteSchedule:
      '往返广州石牌校区生物医学转化研究院、广东暨德康民GMP研发中心与珠海/暨大附一院临床中心；周四下午主持研究院与企业转化联合大组会',
    procurementHistoryClue:
      '【真实双轨资金】① 企业商业资金（免招标）：广东暨德康民2025.12获广州金控健康产投B轮增资（GDKM-100在暨大附一院开展晚期肝癌I期临床），广东暨安特博获真格基金/香商投资数千万投资；② 院内纵向经费：国自然重点项目《γδ T细胞介导肿瘤免疫的分子机制》(~300万) + 科技部重点研发/973首席 + 子课题PI面上/海外优青项目簇',
    patentCoInventorsClue:
      'L1掌舵人：尹芝南 ➔ 【企业端拍板】向征（暨德康民执行总经理兼CTO）、王亚杰（董事长）；【院内端把关】吴扬哲（副院长）、杨恒文（IL-27 PI）、高云飞（教授）、罗钧洪（海外优青） ➔ 一线博后：鲁呦呦、裴建、陈娜',
    confirmedAt: '09:30',
  },
  {
    id: 'sysu-ouyang-juan',
    industrySector: 'biomed',
    institution: '中山大学附属第一医院',
    department: '医学检验科',
    scholarName: '欧阳涓',
    title: '医学检验科行政副主任 / 主任技师 / 硕士生导师（L2 分管副职）',
    researchKeywords: '血液肿瘤微小残留病(MRD) 多参数流式细胞免疫分型 临床新检测项目开发',
    englishQuery:
      'Sun Yat-sen University First Affiliated Hospital Ouyang Juan clinical laboratory flow cytometry',
    deptLeaderName: '刘敏（医学检验科正主任 / 主任技师 · L1全科一把手，统筹本部与南沙院区及大额预算终审）',
    personTier: 'L2',
    roleRelationNote:
      '【正副职搭班子关系】刘敏是医学检验科正主任（L1一把手，承担国自然、863子课题及广州市协同创新重大专项，管全科预算签批）；欧阳涓是行政副主任（L2分管二当家，专管流式细胞免疫分型、血液病MRD与新项目开发）。流式与细胞分析类项目进科必须先由欧阳涓技术把关立项，再呈报刘敏主任终审签字。',
    subPiNames:
      '欧阳涓（行政副主任·分管流式细胞与血液诊断，当前拜访对象）、黄彬（副主任/教授·分管微生物与感染检验）',
    firstAuthorNames: '张式鸿（流式室质量把关骨干） / 王哲、林琳（流式细胞室一线主管技师）',
    verifiedReason:
      '医学检验科行政副主任（分管流式细胞免疫分型与血液病MRD监测），与正主任刘敏构成“L1全科正职拍板 + L2亚专科副职把关”核心决策链。',
    officialSiteSchedule:
      '常驻越秀院区医学检验科2号楼3层；周二、周四下午固定在流式细胞室审签疑难血液病MRD报告并与临床MDT会诊',
    procurementHistoryClue:
      '科室现有常规8-10色流式细胞仪（BD Canto/Navios），随血液内科CAR-T与白血病MRD高敏监测样本激增面临通道受限与串色瓶颈，正由欧阳涓副主任牵头评估全光谱流式与新项目引进，报刘敏主任审批',
    patentCoInventorsClue:
      '向上汇报：刘敏（医学检验科正主任·L1终审）；平级协同：黄彬（副主任）；下属执行：张式鸿、王哲（流式室实操骨干）',
    confirmedAt: '09:20',
  },
  {
    id: 'sysu-liu-min',
    industrySector: 'biomed',
    institution: '中山大学附属第一医院',
    department: '医学检验科',
    scholarName: '刘敏',
    title: '医学检验科主任（正职） / 主任技师 / 博士后合作导师（L1 科室一把手）',
    researchKeywords: '感染免疫与自身免疫诊断 肿瘤分子标志物 临床实验室规划与跨院区质量管理',
    englishQuery:
      'Sun Yat-sen University First Affiliated Hospital Min Liu Department of Laboratory Medicine',
    deptLeaderName: '刘敏（医学检验科正主任 / 主任技师 · L1全科一把手，当前拜访对象）',
    personTier: 'L1',
    roleRelationNote:
      '【正副职分工与授权关系】刘敏任医学检验科正主任（L1一把手，兼管南沙院区，承担国自然、国家863计划子课题、省科技厅及广州市协同创新重大专项），抓总全科实验室规划、质量认证与分子/生化免疫；科内【流式细胞免疫分型、血液病MRD及细胞分析新项目】具体授权给行政副主任欧阳涓（欧阳娟，L2二当家）分管把关。推流式项目切忌越过欧阳涓只找刘敏；推感染免疫/肿瘤分子标志物或全科流水线则直接对齐刘敏主任。',
    subPiNames:
      '欧阳涓（行政副主任/主任技师·分管流式细胞免疫分型与血液MRD新项目开发）、黄彬（副主任/教授·分管临床微生物检验）',
    firstAuthorNames: '张式鸿（专业组技术主管） / 王哲、林琳（检验科一线主管技师与驻科博后）',
    verifiedReason:
      '医学检验科正主任（全科一把手），主持或参与国自然、863子课题及广州市协同创新重大专项，统筹院本部及南沙院区年度设备购置计划终审；流式与血液亚专科具体授权行政副主任欧阳涓把关。',
    officialSiteSchedule:
      '统筹越秀院本部与南沙院区医学检验科行政与质量管理；周三下午固定主持全科质量管理与新项目立项办公会',
    procurementHistoryClue:
      '拥有国家临床重点专科建设经费、省市协同创新重大专项及跨院区设备预算；重点关注院本部与南沙院区检验质量同质化、感染免疫/肿瘤标志物高通量平台及欧阳涓副主任提报的流式MRD升级专项',
    patentCoInventorsClue:
      '核心副手（L2二当家）：欧阳涓（行政副主任·管流式与血液）、黄彬（副主任·管微生物）；技术把关（L3）：张式鸿与科室科研秘书',
    confirmedAt: '09:25',
  },
  {
    id: 'byd-semicon-chen-gang',
    industrySector: 'semicon_mfg',
    institution: '比亚迪半导体股份有限公司',
    department: '功率半导体事业部 / 车规级SiC模块封装与失效分析(FA)中心',
    scholarName: '陈刚',
    title: '总经理 / 车规功率半导体首席专家（L1 事业部一把手）',
    researchKeywords: '车规级1200V SiC MOSFET模块 双面银烧结空洞率控制 在线3D AXI/超声扫描良率检测',
    englishQuery: 'BYD Semiconductor SiC power module silver sintering void inspection reliability',
    deptLeaderName: '陈刚（功率半导体事业部总经理 · L1一把手）',
    personTier: 'L1',
    roleRelationNote:
      '陈刚总经理负责事业部产线扩产CapEx与合格供应商名录(AVL)终审；日常车规SiC模块封装工艺验证与≤10万FA委外测试预算由封装副总吴海平与FA总监林建华（L2实权二当家）直接签批。',
    subPiNames: '吴海平（SiC封装工艺副总）、林建华（失效分析FA实验室总监，握有≤10万测试打样签批权）',
    firstAuthorNames: '张志强 / 刘宇（封装可靠性主任工程师，负责产线3D检测与FA分析）',
    verifiedReason: '统领车规IGBT与SiC功率模块量产与二期产线扩建，具体设备验证由封装工艺副总与FA总监负责。',
    officialSiteSchedule:
      '常驻深圳坪山总部基地与宁波晶圆制造基地；双周三下午固定主持车规模块良率与失效分析评审会',
    procurementHistoryClue:
      '产线现有设备以2D X-Ray与离线超声C-SAM为主，二期车规SiC模块扩产急需导入纳米级3D AXI在线无损检测与高通量电镜FA方案',
    patentCoInventorsClue:
      '吴海平、林建华、张志强（车规功率模块银烧结空洞控制与良率提升核心技术团队）',
    confirmedAt: '10:15',
  },
  {
    id: 'cmb-fintech-zhou',
    industrySector: 'enterprise_ai',
    institution: '招商银行总行信息技术部',
    department: '云原生与人工智能算力架构中心',
    scholarName: '周天虹',
    title: '信息技术部总经理（L1 科技条线一把手）',
    researchKeywords: '金融大模型私有化低延时推理集群 分布式向量数据库信创替代 投研智能体数据安全',
    englishQuery: 'China Merchants Bank FinTech AI infrastructure cloud native vector database',
    deptLeaderName: '周天虹（总行信息技术部总经理 · L1一把手）',
    personTier: 'L1',
    roleRelationNote:
      '周天虹总经理主持总行技术委员会年度预算终审；日常AI算力与向量检索POC沙箱立项（≤15万敏捷预算）由二级中心主任李云与首席架构师郑伟（L2二当家）直接负责。',
    subPiNames: '李云（AI算力与基础架构二级中心主任）、郑伟（总行首席架构师，握有≤15万POC验证签批权）',
    firstAuthorNames: '陈思远 / 王凯（大模型推理优化与信创存储架构师，负责POC压测评估）',
    verifiedReason: '负责总行科技战略与年度预算终审，日常POC压测立项与年度集采技术规范由二级中心主任与首席架构师把关。',
    officialSiteSchedule:
      '常驻深圳总行科技大厦；每季度末主持基础架构选型评审与下一年度重点POC立项会',
    procurementHistoryClue:
      '前期已完成首批通用算力采购，当前核心痛点为百亿参数模型并发推理显存瓶颈与千亿向量毫秒级混合检索信创改造',
    patentCoInventorsClue:
      '李云、郑伟、陈思远（总行智能风控与混合向量检索架构核心设计与测试团队）',
    confirmedAt: '10:30',
  },
  {
    id: 'wanhua-chem-hua',
    industrySector: 'chem_materials',
    institution: '万华化学集团中央研究院',
    department: '高性能聚合物研究所 / 聚烯烃弹性体(POE)催化工程中心',
    scholarName: '华卫琦',
    title: '集团常务副总裁 / 中央研究院院长（L1 研究院一把手）',
    researchKeywords: '茂金属POE催化剂高通量筛选 高温在线流变与凝胶渗透色谱(GPC) 连续聚合中试放大',
    englishQuery: 'Wanhua Chemical Central Research Institute polyolefin elastomer metallocene catalyst',
    deptLeaderName: '华卫琦（集团常务副总裁 / 中央研究院院长 · L1一把手）',
    personTier: 'L1',
    roleRelationNote:
      '华卫琦院长把控万吨级产业化与重大装备终审；具体POE催化剂筛选与中试线在线表征选型（≤8万所级测试预算）由副院长黎源与研究所所长张永振（L2二当家）直接拍板。',
    subPiNames: '黎源（中央研究院副院长）、张永振（聚烯烃催化剂研究所所长，握有≤8万定制表征签批权）',
    firstAuthorNames: '孙明 / 赵磊（研发骨干，负责每日催化剂活性评价与高温GPC/NMR表征）',
    verifiedReason: '全面负责集团新材料研发管线，中试装置表征设备选型与日常测试委外由分管副院长与研究所所长直接决策。',
    officialSiteSchedule:
      '常驻烟台磁山全球研发总部；每周五下午研究所固定召开小试转中试表征数据复盘会',
    procurementHistoryClue:
      '烟台与蓬莱基地POE/特种聚烯烃中试放大线加快建设，离线送检滞后严重，急需高温高粘度样品防堵管在线表征与快速分子量测定方案',
    patentCoInventorsClue:
      '黎源、张永振、孙明（耐高温茂金属催化剂合成与连续聚合中试放大核心攻关团队）',
    confirmedAt: '10:50',
  },
  {
    id: 'sysu-chen-minhu',
    industrySector: 'biomed',
    institution: '中山大学附属第一医院',
    department: '消化内科 / 炎症性肠病(IBD)中心',
    scholarName: '陈旻湖',
    title: '消化内科首席专家 / 原副院长（L1 学科带头人）',
    researchKeywords: '炎症性肠病(IBD) 肠道黏膜免疫微环境 生物制剂耐药 空间多组学',
    englishQuery:
      'Sun Yat-sen University Minhu Chen inflammatory bowel disease mucosal immunology',
    deptLeaderName: '陈旻湖（消化内科首席专家 / 学科带头人 · L1一把手）',
    personTier: 'L1',
    roleRelationNote:
      '陈旻湖教授是消化内科学科泰斗（L1终审），日常IBD黏膜免疫与肠纤维化子课题推进及5万内测试费直签由核心弟子毛仁、冯瑞（L2青年PI二当家）具体操盘。',
    subPiNames: '毛仁（主任医师/青年PI）、冯瑞（研究员/黏膜免疫子课题负责人）、陈白莉（主任医师）',
    firstAuthorNames: '庄楠 / 李俊（消化内科实验室专职博后）',
    verifiedReason: '消化内科学科带头人，旗下毛仁、冯瑞等青年PI具体操盘子课题并直接签批5万内测试费。',
    officialSiteSchedule:
      '越秀院区周一、周三上午IBD专家门诊，周四下午主持消化内科重点实验室大组会',
    procurementHistoryClue:
      '科室拥有大型内镜活检样本库与基础病理设备，当前在生物制剂耐药机制研究中亟需单张切片6-8色空间病理原位共染与微量蛋白定量支撑',
    patentCoInventorsClue:
      '毛仁、冯瑞、庄楠（肠黏膜免疫微环境与疗效预测标志物核心子课题团队）',
    confirmedAt: '11:05',
  },
  {
    id: 'sysu-kuang-ming',
    industrySector: 'biomed',
    institution: '中山大学附属第一医院',
    department: '肝胆胰外科中心 / 精准医学研究院',
    scholarName: '匡铭',
    title: '副院长 / 肝胆胰外科中心学科带头人 / 教授（L1 院级一把手）',
    researchKeywords: '肝癌消融微环境重塑 TLS三级淋巴结构 单细胞与空间多组学图谱',
    englishQuery: 'Sun Yat-sen University Ming Kuang hepatocellular carcinoma ablation immune',
    deptLeaderName: '匡铭（副院长 / 肝胆胰外科中心学科带头人 · L1一把手）',
    personTier: 'L1',
    roleRelationNote:
      '匡铭副院长统管精准医学研究院与外科中心大方向（L1终审）；研究院日常管理、子课题推进与小额经费签批由精准医学研究院副院长彭穗及林满霞副教授（L2实权二当家）负责。',
    subPiNames: '彭穗（精准医学研究院副院长/教授）、林满霞（副教授/子课题PI）、许丽霞（副研究员）',
    firstAuthorNames: '谢晓华 / 陈志（精准医学研究院专职博后）',
    verifiedReason: '全面统领肝胆胰外科与精准医学研究院战略，研究院日常课题推进与设备选型由副院长彭穗及林满霞等青年PI负责。',
    officialSiteSchedule:
      '分管精准医学研究院与院级管理工作，日常行程紧凑；研究院平台建设与课题实验由彭穗副院长及专职科研秘书统筹',
    procurementHistoryClue:
      '精准医学研究院公共平台年运行负荷超1800小时，正推进全光谱流式分选与空间多组学工作站升级论证',
    patentCoInventorsClue:
      '彭穗、林满霞、谢晓华（肝癌消融后免疫微环境重塑与空间多组学核心执行团队）',
    confirmedAt: '11:20',
  },
];

const CustomerContext = createContext<CustomerContextValue | undefined>(undefined);

export const CustomerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [customerHistory, setCustomerHistory] = useState<ConfirmedCustomerProfile[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_HISTORY_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // ignore storage errors
    }
    return INITIAL_SEED_HISTORY;
  });

  const [confirmedCustomer, setConfirmedCustomer] = useState<ConfirmedCustomerProfile | null>(() => {
    try {
      const savedActive = localStorage.getItem(STORAGE_ACTIVE_KEY);
      if (savedActive) {
        return JSON.parse(savedActive);
      }
    } catch {
      // ignore
    }
    return INITIAL_SEED_HISTORY[0]; // Default to 尹芝南 (with 欧阳涓 & 刘敏 right next to it in top bar)
  });

  const [activeIndustry, setActiveIndustryState] = useState<IndustrySectorId>(
    confirmedCustomer?.industrySector || 'biomed'
  );

  const [isSelectingCustomer, setIsSelectingCustomer] = useState<boolean>(false);

  const setActiveIndustry = (sector: IndustrySectorId) => {
    setActiveIndustryState(sector);
  };

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(customerHistory));
    } catch {
      // ignore
    }
  }, [customerHistory]);

  useEffect(() => {
    try {
      if (confirmedCustomer) {
        localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(confirmedCustomer));
        if (confirmedCustomer.industrySector) {
          setActiveIndustryState(confirmedCustomer.industrySector);
        }
      } else {
        localStorage.removeItem(STORAGE_ACTIVE_KEY);
      }
    } catch {
      // ignore
    }
  }, [confirmedCustomer]);

  const confirmCustomer = (
    profile: Omit<ConfirmedCustomerProfile, 'id' | 'confirmedAt' | 'title' | 'englishQuery'> & {
      id?: string;
      title?: string;
      englishQuery?: string;
    }
  ): ConfirmedCustomerProfile => {
    const cleanName = profile.scholarName.trim() || '目标客户';
    const isYinZhinan =
      cleanName.includes('尹芝南') ||
      cleanName.includes('尹之南') ||
      cleanName.includes('吴扬哲') ||
      cleanName.includes('向征') ||
      cleanName.includes('杨恒文') ||
      cleanName.includes('高云飞') ||
      cleanName.includes('罗钧洪') ||
      cleanName.includes('暨德康民') ||
      cleanName.includes('暨安特博');

    const cleanInst =
      isYinZhinan &&
      (!profile.institution || profile.institution.includes('中山大学附属第一医院'))
        ? '暨南大学'
        : profile.institution.trim() || '中山大学附属第一医院';
    const cleanDept =
      isYinZhinan &&
      (!profile.department ||
        profile.department.includes('医学检验科') ||
        profile.department.includes('消化'))
        ? '生物医学转化研究院 / 广东暨德康民 & 暨安特博（名下转化企业） / 珠海市人民医院精准医学中心'
        : profile.department.trim() || '重点实验室 / 研发中心';

    const generatedId =
      profile.id ||
      `${cleanInst}-${cleanDept}-${cleanName}`.replace(/\s+/g, '-').toLowerCase();

    const nowStr = new Date().toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });

    const sector: IndustrySectorId =
      profile.industrySector ||
      (cleanInst.includes('半导体') || cleanInst.includes('宁德') || cleanInst.includes('制造')
        ? 'semicon_mfg'
        : cleanInst.includes('银行') || cleanInst.includes('电网') || cleanInst.includes('科技')
        ? 'enterprise_ai'
        : cleanInst.includes('万华') || cleanInst.includes('石化') || cleanInst.includes('化工')
        ? 'chem_materials'
        : activeIndustry);

    const isChenMinhu =
      cleanName.includes('陈旻湖') ||
      cleanName.includes('陈文湖') ||
      cleanName.includes('毛仁') ||
      (!cleanName && cleanDept.includes('消化'));
    const isKuangMing =
      cleanName.includes('匡铭') ||
      cleanName.includes('彭穗') ||
      cleanName.includes('林满霞') ||
      (!cleanName && cleanDept.includes('肝胆'));
    const isLabMedicine =
      cleanName.includes('欧阳涓') ||
      cleanName.includes('欧阳娟') ||
      cleanName.includes('刘敏') ||
      cleanName.includes('黄彬') ||
      cleanName.includes('张式鸿') ||
      (!isYinZhinan &&
        !isChenMinhu &&
        !isKuangMing &&
        cleanDept.includes('检验') &&
        (cleanName.includes('欧阳') || cleanName.includes('刘') || cleanName.includes('王哲')));
    const isLiuMin = cleanName.includes('刘敏');
    const isOuyangJuan = cleanName.includes('欧阳涓') || cleanName.includes('欧阳娟');
    const isYangHengwen =
      cleanName.includes('杨恒文') ||
      cleanName.includes('高云飞') ||
      cleanName.includes('吴扬哲') ||
      cleanName.includes('向征') ||
      cleanName.includes('罗钧洪');
    const isDeputyRole =
      isOuyangJuan ||
      isYangHengwen ||
      cleanName.includes('彭穗') ||
      cleanName.includes('毛仁') ||
      (profile.title || '').includes('副主任') ||
      (profile.title || '').includes('副院长') ||
      (profile.title || '').includes('副所长') ||
      (profile.title || '').includes('副教授');

    const defaultDeptLeader =
      sector === 'semicon_mfg'
        ? `陈刚（${cleanDept}总经理 / 事业部一把手 · L1终审）`
        : sector === 'enterprise_ai'
        ? `周天虹（${cleanDept}总经理 / 科技条线一把手 · L1终审）`
        : sector === 'chem_materials'
        ? `华卫琦（中央研究院院长 / 集团常务副总裁 · L1终审）`
        : isYinZhinan
        ? `尹芝南（暨大生物医学转化研究院院长 + 广东暨德康民创始人/大股东[持股~33%] + 广东暨安特博科学创始人 + 普锐生物首席科学家 + 珠海市人民医院学术总监）`
        : isLabMedicine
        ? `刘敏（医学检验科正主任 / 主任技师 · L1全科一把手，统筹本部与南沙院区及大额预算终审）`
        : isChenMinhu
        ? `陈旻湖（消化内科首席专家 / 学科带头人 · L1全科一把手）`
        : isKuangMing
        ? `匡铭（副院长 / 肝胆胰外科中心学科带头人 · L1院级一把手）`
        : isDeputyRole
        ? `${cleanDept}正主任 / 学科带头人（L1科室一把手 · 掌管百万级年度预算终审）`
        : `${cleanName}（${cleanDept}主任 / 学科带头人 · L1一把手）`;

    const defaultPersonTier: 'L1' | 'L2' | 'L3' | 'L4' =
      profile.personTier ||
      (isLiuMin || cleanName.includes('尹芝南') ? 'L1' : isDeputyRole ? 'L2' : 'L1');

    const defaultRoleRelationNote =
      profile.roleRelationNote ||
      (isYinZhinan
        ? '【体制内研究院 + 院外名下商业药企双栖全景】① 院内班子：尹芝南任院长（国家杰青30725015、长江学者、973首席），副院长【吴扬哲教授】分管院内平台与γδ-T评价，【杨恒文】（IL-27与肠道微生态）、【高云飞】（γδ-T与银屑病JCI）、【罗钧洪】（海外优青·AI单细胞MIST模型）分管各主力子课题；② 院外名下企业：创办【广东暨德康民生物科技有限公司】（持股约33%，董事长王亚杰，院内PI【向征博士】兼任执行总经理兼CTO，2025年12月获广州金控健康产投B轮增资，中国首个异体γδ-T新药GDKM-100在暨大附一院开展晚期肝癌I期临床）及【广东暨安特博生物科技有限责任公司】（获真格基金、香商投资数千万投资研发IL-27新药），并任【普锐生物】首席科学家。'
        : isLabMedicine
        ? isLiuMin
          ? '【正副职分工与授权关系】刘敏任医学检验科正主任（L1一把手，兼管南沙院区，承担国自然、863子课题及广州市协同创新重大专项），抓总全科实验室规划、质量认证与感染/肿瘤分子标志物；科内【流式细胞免疫分型、血液病MRD及细胞分析新项目】具体授权给行政副主任欧阳涓（欧阳娟，L2分管二当家）把关。'
          : '【正副职搭班子关系】刘敏是医学检验科正主任（L1一把手，管全科规划与大额预算签批）；欧阳涓是行政副主任（L2分管二当家，专管流式细胞免疫分型、血液病MRD与新项目开发）。流式与细胞分析类项目进科必须先由欧阳涓技术把关立项，再呈报刘敏主任终审签字。'
        : isChenMinhu
        ? '陈旻湖教授为消化内科学科带头人（L1一把手），日常IBD黏膜免疫子课题与5万内测试费签批授权给毛仁、冯瑞（L2青年PI二当家）。'
        : isKuangMing
        ? '匡铭副院长统管精准医学研究院与外科中心大方向（L1一把手），研究院日常平台管理与子课题推进由彭穗副院长、林满霞副教授（L2二当家）具体操盘。'
        : `科室内部遵循“L1正主任终审拍板（${defaultDeptLeader.split('（')[0]}） ➔ L2分管副主任/实权二当家技术立项与小额签批”的协同机制。`);

    const defaultSubPi =
      sector === 'semicon_mfg'
        ? `吴海平（封装工艺副总）、林建华（${cleanDept}失效分析FA总监，握有≤10万测试打样签批权）`
        : sector === 'enterprise_ai'
        ? `李云（${cleanDept}二级中心主任）、郑伟（首席架构师，握有≤15万POC验证签批权）`
        : sector === 'chem_materials'
        ? `黎源（研究院副院长）、张永振（${cleanDept}所长，握有≤8万定制表征签批权）`
        : isYinZhinan
        ? '向征（转化研究院PI + 广东暨德康民执行总经理兼CTO·掌管GDKM-100临床与企业采购权）、吴扬哲（生物医学转化研究院副院长/教授·分管平台与γδ-T评价）、杨恒文（副研究员/PI·肠道微生态与IL-27代谢）、高云飞（教授/PI·γδ-T与银屑病代谢）、罗钧洪（教授/海外优青·AI单细胞多组学）'
        : isLabMedicine
        ? '欧阳涓（医学检验科行政副主任/主任技师·分管流式细胞免疫分型与血液MRD新项目开发）、黄彬（医学检验科副主任/教授·分管临床微生物检验）'
        : isChenMinhu
        ? '毛仁（主任医师/青年PI）、冯瑞（研究员/黏膜免疫子课题负责人）、陈白莉（主任医师）'
        : isKuangMing
        ? '彭穗（精准医学研究院副院长/教授）、林满霞（副教授/子课题PI）、许丽霞（副研究员）'
        : `${cleanDept}分管副主任 / 共同通讯青年PI（握有≤5万测试费直接签字权）`;

    const defaultFirstAuthor =
      sector === 'semicon_mfg'
        ? '张志强 / 刘宇（产线FA可靠性主任工程师）'
        : sector === 'enterprise_ai'
        ? '陈思远 / 王凯（一线核心系统架构师与POC压测负责人）'
        : sector === 'chem_materials'
        ? '孙明 / 赵磊（研发骨干，负责日常小试与中试表征）'
        : isYinZhinan
        ? '鲁呦呦 / 裴建 / 陈娜 / 王倩（γδ-T细胞分选扩增、GDKM-100临床样本监测与IL-27代谢免疫一线专职博后）'
        : isLabMedicine
        ? '张式鸿（流式与临检专业组质量把关骨干） / 王哲、林琳（流式细胞室一线主管技师）'
        : isChenMinhu
        ? '庄楠 / 李俊（消化内科实验室专职博后）'
        : isKuangMing
        ? '谢晓华 / 陈志（精准医学研究院专职博后）'
        : `${cleanDept}一线主管技师 / 专职实验博后`;

    const defaultSchedule =
      sector === 'semicon_mfg'
        ? `常驻${cleanInst}研发与制造基地；双周三下午固定主持产线良率与FA评审会`
        : sector === 'enterprise_ai'
        ? `常驻${cleanInst}研发中心；每季度末主持新架构POC基准测试与选型评审`
        : sector === 'chem_materials'
        ? `常驻${cleanInst}研发总部；每周五下午召开小试转中试表征数据复盘会`
        : isYinZhinan
        ? `往返广州石牌校区生物医学转化研究院、广东暨德康民GMP研发中心与珠海/暨大附一院临床中心；周四下午主持研究院与企业转化联合大组会`
        : isLiuMin
        ? `统筹越秀院本部与南沙院区医学检验科管理；周三下午固定主持全科质量管理与新项目立项办公会`
        : isOuyangJuan
        ? `常驻越秀院区医学检验科2号楼3层；周二、周四下午固定在流式细胞室审签复杂血液病MRD报告`
        : `常驻${cleanInst}${cleanDept}；周二、周四下午固定在实验室或组会处理科研事务`;

    const defaultProcurement =
      sector === 'semicon_mfg'
        ? `${cleanInst}新产线扩产推进中，现有设备以传统2D检测为主，亟待导入高分辨率3D无损检测与FA分析方案`
        : sector === 'enterprise_ai'
        ? `${cleanInst}已完成前期基础硬件建设，当前重点推进软件底座升级与低延时推理POC验证`
        : sector === 'chem_materials'
        ? `${cleanInst}新材料中试放大线建设推进中，急需耐高温防堵管在线表征与高通量筛选系统`
        : isYinZhinan
        ? '【真实双轨资金】① 企业商业资金（免高校招标直采）：名下广东暨德康民2025.12获广州金控健康产投B轮增资（中国首个异体Vγ9Vδ2-T新药GDKM-100在暨大附一院启动晚期肝癌I期临床），名下广东暨安特博获真格基金/香商投资数千万投资推进IL-27新药；② 院内纵向经费：国自然重点项目《γδ T细胞介导肿瘤免疫的分子机制》(~300万) + 科技部重点研发/973首席 + 子课题PI面上/海外优青项目簇'
        : isLabMedicine
        ? isLiuMin
          ? '拥有国家临床重点专科建设经费、国自然/863子课题/广州市协同创新重大专项；重点关注跨院区检验质量同质化、感染免疫/肿瘤分子标志物高通量平台及欧阳涓副主任提报的流式MRD升级专项'
          : '科室现有8-10色常规流式面临血液科CAR-T与MRD高敏监测通道瓶颈，正由欧阳涓副主任牵头评估高维流式与新项目引进，报刘敏主任终审'
        : `${cleanInst}${cleanDept}现有设备为基础型号，随在研队列扩增正处于下一年度平台升级比价阶段`;

    const defaultPatent =
      sector === 'semicon_mfg'
        ? `吴海平、林建华、张志强（负责「${profile.researchKeywords || '车规模块良率控制'}」工艺验证与FA测试把关）`
        : sector === 'enterprise_ai'
        ? `李云、郑伟、陈思远（负责「${profile.researchKeywords || '高并发智能架构'}」架构设计与POC压测评估）`
        : sector === 'chem_materials'
        ? `黎源、张永振、孙明（负责「${profile.researchKeywords || '高性能催化聚合'}」中试放大与表征方案审定）`
        : isYinZhinan
        ? 'L1总掌舵人：尹芝南 ➔ 【企业端直接拍板】向征（广东暨德康民执行总经理兼CTO）、王亚杰（董事长）；【院内端把关】吴扬哲（副院长）、杨恒文（IL-27 PI）、高云飞（教授）、罗钧洪（海外优青） ➔ 一线博后：鲁呦呦、裴建、陈娜'
        : isLabMedicine
        ? 'L1科室正主任：刘敏（全科拍板） ➔ L2分管副主任：欧阳涓（流式/血液把关）、黄彬（微生物把关） ➔ L3/L4流式室骨干：张式鸿、王哲'
        : `子课题青年PI与实验室骨干（负责「${profile.researchKeywords || '临床转化研究'}」具体实验推进与小额经费签批）`;

    const resolvedKeywords =
      isYinZhinan &&
      (!profile.researchKeywords ||
        profile.researchKeywords.includes('MRD') ||
        profile.researchKeywords.includes('血栓'))
        ? '同种异体Vγ9Vδ2-T细胞新药(GDKM-100) · IL-27靶向脂肪产热减肥与代谢免疫(Nature) · 肿瘤免疫微环境转化'
        : profile.researchKeywords || '核心技术攻关与平台升级';

    const newConfirmed: ConfirmedCustomerProfile = {
      id: generatedId,
      industrySector: sector,
      institution: cleanInst,
      department: cleanDept,
      scholarName: cleanName,
      title:
        profile.title ||
        (isYinZhinan
          ? cleanName.includes('杨恒文')
            ? '生物医学转化研究院副院长 / 教授 / 博导（L2 分管副职）'
            : '生物医学转化研究院院长 / 教授 / 国家杰青 / 首席科学家（L1 研究院一把手）'
          : isLiuMin
          ? '医学检验科主任（正职） / 主任技师 / 博士后合作导师（L1 科室一把手）'
          : isOuyangJuan
          ? '医学检验科行政副主任 / 主任技师 / 硕士生导师（L2 分管副职）'
          : '部门负责人 / 首席专家 / 学科带头人'),
      researchKeywords: resolvedKeywords,
      englishQuery:
        isYinZhinan
          ? 'Jinan University Zhinan Yin gamma delta T cells tumor immunotherapy IL-27'
          : profile.englishQuery || `${cleanInst} ${cleanName} ${resolvedKeywords}`,
      correctionBadge: profile.correctionBadge,
      deptLeaderName: profile.deptLeaderName || defaultDeptLeader,
      personTier: defaultPersonTier,
      roleRelationNote: defaultRoleRelationNote,
      subPiNames: profile.subPiNames || defaultSubPi,
      firstAuthorNames: profile.firstAuthorNames || defaultFirstAuthor,
      verifiedReason:
        profile.verifiedReason ||
        `${cleanInst}·${cleanDept}核心业务与平台建设负责人。`,
      officialSiteSchedule: profile.officialSiteSchedule || defaultSchedule,
      procurementHistoryClue: profile.procurementHistoryClue || defaultProcurement,
      patentCoInventorsClue: profile.patentCoInventorsClue || defaultPatent,
      confirmedAt: nowStr,
    };

    setConfirmedCustomer(newConfirmed);
    setActiveIndustryState(sector);
    setCustomerHistory((prev) => {
      const filtered = prev.filter(
        (item) =>
          item.id !== newConfirmed.id &&
          !(
            item.scholarName === newConfirmed.scholarName &&
            item.institution === newConfirmed.institution
          )
      );
      return [newConfirmed, ...filtered].slice(0, 12);
    });
    setIsSelectingCustomer(false);
    return newConfirmed;
  };

  const selectFromHistory = (id: string) => {
    const target = customerHistory.find((item) => item.id === id);
    if (target) {
      setConfirmedCustomer(target);
      if (target.industrySector) {
        setActiveIndustryState(target.industrySector);
      }
      setIsSelectingCustomer(false);
    }
  };

  const removeFromHistory = (id: string) => {
    setCustomerHistory((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <CustomerContext.Provider
      value={{
        activeIndustry,
        setActiveIndustry,
        confirmedCustomer,
        customerHistory,
        isSelectingCustomer,
        setIsSelectingCustomer,
        confirmCustomer,
        selectFromHistory,
        removeFromHistory,
      }}
    >
      {children}
    </CustomerContext.Provider>
  );
};

export const useCustomerContext = () => {
  const ctx = useContext(CustomerContext);
  if (!ctx) {
    throw new Error('useCustomerContext must be used within a CustomerProvider');
  }
  return ctx;
};
